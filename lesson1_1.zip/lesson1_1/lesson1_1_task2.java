package lesson1_1;
public class lesson1_1_task2 {

        public static void main(String[] args) {
            System.out.println("Sheparevich Yuliya" + "\n" + "Esenina 6-107" + "\n" + "+375-29-120-24-49");
        }

}
